## Opus Plan

*   When a task requires multiple steps, create a detailed plan.
*   The plan should consist of a series of atomic steps, each with a clear goal and rollback procedure.
*   Each step in the plan will be executed by the Sonnet model.