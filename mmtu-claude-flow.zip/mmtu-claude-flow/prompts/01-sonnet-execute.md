## Sonnet Execute

*   Execute the given task as an atomic step.
*   The step must complete in under 10 minutes.
*   If the task is too complex, break it down into smaller steps and create a plan.
*   All file system and shell operations must be within the allowed paths.
*   Do not log any secrets or sensitive information.