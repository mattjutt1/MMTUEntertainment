## Handoff Block

*   **Goal**: {{goal}}
*   **Constraints**: {{constraints}}
*   **Files**: {{files}}
*   **Test**: {{test}}
*   **Done**: {{done}}
*   **Rollback**: {{rollback}}