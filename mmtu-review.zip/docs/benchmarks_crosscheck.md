# Benchmarks Cross-Check
| KPI              | Perplexity | Manual Research | Status | Notes                          |
|------------------|------------|-----------------|--------|--------------------------------|
| LTV:CAC          | —          | 0.02–0.95       | Conflict | Below the 3:1 scale threshold |
| W4 Retention     | ≥ 20%      | ≥ 20%           | Aligned | Kill <10%                     |
| Gross Margin     | ≥ 60%      | ≥ 60%           | Aligned | —                              |
