# Pivot Rules — Reality-Based Governance
- Scale requires: LTV:CAC ≥ 3, W4 ≥ 20%, Gross margin ≥ 60%, Smoke conv ≥ 5%
- Kill triggers: W4 < 10%, CAC not breakeven after 2 cycles, or adoption < 10%
- Maintain ≥ 3 revenue streams; evidence tier must be Tier 2+ to scale.
